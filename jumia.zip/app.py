from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_mail import Mail, Message
from models import db, User, Product, Order
from werkzeug.utils import secure_filename
import os
import uuid
import jwt
import datetime
from datetime import datetime, timedelta
import base64
import requests
from functools import wraps
from flask_cors import cross_origin
from flask_migrate import Migrate
# Initialize Flask App
app = Flask(__name__)
application = app

CORS(app)

app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ecommerce.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Configure Flask-Mail with Gmail SMTP settings
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'marierareagan@gmail.com'
app.config['MAIL_PASSWORD'] = 'lietamatwojkhumw'
app.config['MAIL_DEFAULT_SENDER'] = 'marierareagan@gmail.com'

mail = Mail(app)

# Initialize DB
db.init_app(app)
migrate = Migrate(app, db)
# Create tables
with app.app_context():
    db.create_all()

# Allowed file types
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# JWT Authentication decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if not current_user.is_admin:
            return jsonify({'message': 'Admin access required!'}), 403
        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()

    if not data or not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Missing required fields'}), 400

    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists'}), 400

    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already registered'}), 400

    is_admin_request = data.get('is_admin', False)
    requesting_user = None

    if 'Authorization' in request.headers:
        token = request.headers['Authorization'].split(" ")[1]
        try:
            decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            requesting_user = User.query.get(decoded['user_id'])
        except:
            pass

    new_user = User(
        username=data['username'],
        email=data['email'],
        is_admin=is_admin_request
    )
    new_user.set_password(data['password'])

    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'User created successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()

    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'message': 'Missing username or password'}), 400

    user = User.query.filter_by(username=data['username']).first()

    if not user or not user.check_password(data['password']):
        return jsonify({'message': 'Invalid credentials'}), 401

    token = jwt.encode({
        'user_id': user.id,
        'exp': datetime.utcnow() + timedelta(hours=24)
    }, app.config['SECRET_KEY'])

    return jsonify({
        'token': token,
        'user': user.to_dict()
    })

@app.route('/api/products', methods=['GET'])
def get_products():
    query = request.args.get('q')
    min_price = request.args.get('min')
    max_price = request.args.get('max')
    category = request.args.get('category')  # Add this line

    filters = []
    if query:
        filters.append(Product.name.ilike(f"%{query}%"))
    if min_price:
        filters.append(Product.price >= float(min_price))
    if max_price:
        filters.append(Product.price <= float(max_price))
    if category:
        filters.append(Product.category == category)  # Add this line

    # Get token if present
    current_user = None
    if 'Authorization' in request.headers:
        token = request.headers['Authorization'].split(" ")[1]
        try:
            decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(decoded['user_id'])
        except:
            pass

    # Show all matching products regardless of approval status
    products = Product.query.filter(*filters).all()

    return jsonify([product.to_dict() for product in products])


@app.route('/api/test-email', methods=['POST'])
def test_email():
    data = request.get_json()
    recipient_email = data.get('email')

    if not recipient_email:
        return jsonify({'message': 'Recipient email is required'}), 400

    try:
        # Create a test email message
        msg = Message("Test Email", recipients=[recipient_email])
        msg.body = "This is a test email to verify the email configuration."
        msg.sender = app.config['MAIL_DEFAULT_SENDER']

        # Send the email
        mail.send(msg)

        return jsonify({'message': 'Test email sent successfully'}), 200
    except Exception as e:
        return jsonify({'message': f'Failed to send test email: {str(e)}'}), 500

@app.route('/api/buy/<int:product_id>', methods=['POST'])
@token_required
def buy_product(current_user, product_id):
    data = request.get_json()
    product = Product.query.get_or_404(product_id)

    if not product.is_approved:
        return jsonify({'message': 'Product is not available for purchase'}), 400

    if product.user_id == current_user.id:
        return jsonify({'message': 'You cannot buy your own product'}), 400

    # Extract order details from request
    phone_number = data.get('phone_number')
    email = data.get('email')
    location = data.get('location')

    if not phone_number or not email or not location:
        return jsonify({'message': 'Missing required order details'}), 400

    new_order = Order(
        product_id=product_id,
        user_id=current_user.id,
        phone_number=phone_number,
        email=email,
        location=location,
        status='pending'
    )

    db.session.add(new_order)
    db.session.commit()

    # Send email notifications
    try:
        send_order_notification(current_user, product, new_order)
    except Exception as e:
        print(f"Failed to send email notifications: {e}")

    return jsonify({'message': 'Order placed successfully'}), 200

def send_order_notification(user, product, order):
    try:
        # Email to user
        user_msg = Message("Order Confirmation", recipients=[user.email])
        user_msg.body = f"Thank you {user.username} for your order! Your order for {product.name} has been placed and is being processed."
        user_msg.sender = app.config['MAIL_DEFAULT_SENDER']
        mail.send(user_msg)

        # Email to all admins
        admins = User.query.filter_by(is_admin=True).all()
        admin_emails = [admin.email for admin in admins]

        admin_msg = Message("New Order Placed", recipients=admin_emails)
        admin_msg.body = f"""
        A new order has been placed by {user.username} for {product.name}.
        Order ID: {order.id}
        Phone Number: {order.phone_number}
        Location: {order.location}
        """
        admin_msg.sender = app.config['MAIL_DEFAULT_SENDER']
        mail.send(admin_msg)
    except Exception as e:
        print(f"Failed to send email notifications: {e}")
        raise


@app.route('/api/products', methods=['POST'])
@token_required
def create_product(current_user):
    if not current_user.is_admin and not current_user.can_upload:
        return jsonify({
            'message': 'You do not have permission to upload products',
            'reason': 'admin_approval_required',
            'hint': 'Contact admin for upload permission'
        }), 403

    if 'images' not in request.files:
        return jsonify({'message': 'No image file provided'}), 400

    files = request.files.getlist('images')
    if len(files) == 0:
        return jsonify({'message': 'No selected image files'}), 400

    data = request.form
    if not data.get('name'):
        return jsonify({'message': 'Product name is required'}), 400

    if not data.get('price') or not data.get('price').replace('.', '', 1).isdigit():
        return jsonify({'message': 'Valid price is required (e.g., 500)'}), 400

    # Validate first image
    main_file = files[0]
    if not allowed_file(main_file.filename):
        return jsonify({'message': 'Invalid main image file type. Use: png, jpg, jpeg, gif'}), 400

    try:
        filename = secure_filename(main_file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        main_file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_filename))

        # Save extra images
        extra_image_paths = []
        for file in files[1:]:
            if file and allowed_file(file.filename):
                ext_filename = secure_filename(file.filename)
                ext_unique = f"{uuid.uuid4().hex}_{ext_filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], ext_unique))
                extra_image_paths.append(ext_unique)

        new_product = Product(
            name=data['name'],
            description=data.get('description', ''),
            price=float(data['price']),
            image_path=unique_filename,
            extra_images=",".join(extra_image_paths),
            category=data.get('category', ''),
            is_approved=current_user.is_admin,
            user_id=current_user.id
        )

        db.session.add(new_product)
        db.session.commit()

        return jsonify(new_product.to_dict()), 201

    except Exception as e:
        db.session.rollback()
        print("Upload error:", str(e))
        return jsonify({'message': 'Failed to upload product. Please try again later.'}), 500
    
@app.route('/api/cart/checkout', methods=['POST'])
@token_required
def checkout(current_user):
    try:
        data = request.get_json()
        phone_number = data.get('phone_number')
        email = data.get('email')
        location = data.get('location')

        if not phone_number or not email or not location:
            return jsonify({'message': 'Missing required order details'}), 400

        # Retrieve all pending orders for the current user
        pending_orders = Order.query.filter_by(user_id=current_user.id, status='pending').all()

        if not pending_orders:
            return jsonify({'message': 'No items in cart to checkout'}), 400

        # Process each order (e.g., update status, send notifications, etc.)
        for order in pending_orders:
            order.status = 'completed'
            order.phone_number = phone_number
            order.email = email
            order.location = location
            # You can add additional logic here, such as sending notifications, updating inventory, etc.

        db.session.commit()

        # Send email notifications for each order
        try:
            for order in pending_orders:
                product = Product.query.get(order.product_id)
                send_order_notification(current_user, product, order)
        except Exception as e:
            print(f"Failed to send email notifications: {e}")

        # Send a success response
        return jsonify({'message': 'Checkout successful'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to checkout: {str(e)}'}), 500

def send_order_notification(user, product, order):
    try:
        # Email to user
        user_msg = Message("Order Confirmation", recipients=[user.email])
        user_msg.body = f"Thank you for your order! Your order for {product.name} has been placed and is being processed."
        user_msg.sender = app.config['MAIL_DEFAULT_SENDER']
        mail.send(user_msg)

        # Email to all admins
        admins = User.query.filter_by(is_admin=True).all()
        admin_emails = [admin.email for admin in admins]

        admin_msg = Message("New Order Placed", recipients=admin_emails)
        admin_msg.body = f"""
        A new order has been placed by {user.username} for {product.name}.
        Order ID: {order.id}
        Phone Number: {order.phone_number}
        Location: {order.location}
        """
        admin_msg.sender = app.config['MAIL_DEFAULT_SENDER']
        mail.send(admin_msg)
    except Exception as e:
        print(f"Failed to send email notifications: {e}")
        raise


@app.route('/api/cart/add/<int:product_id>', methods=['POST'])
@token_required
def add_to_cart(current_user, product_id):
    # Check if product exists
    product = Product.query.get_or_404(product_id)
    
    # Prevent adding same product multiple times
    existing_order = Order.query.filter_by(
        user_id=current_user.id,
        product_id=product_id,
        status='pending'
    ).first()
    
    if existing_order:
        return jsonify({'message': 'Product already in cart'}), 400
    
    new_order = Order(
        product_id=product_id,
        user_id=current_user.id,
        phone_number="",
        email="",
        location="",
        status='pending',
        timestamp=datetime.utcnow()
    )
    
    db.session.add(new_order)
    db.session.commit()
    
    return jsonify({'message': 'Added to cart', 'order_id': new_order.id}), 201


@app.route('/api/cart/remove/<int:product_id>', methods=['DELETE'])
@token_required
def remove_from_cart(current_user, product_id):
    # Check if the order exists and is pending
    order = Order.query.filter_by(
        user_id=current_user.id,
        product_id=product_id,
        status='pending'
    ).first()

    if not order:
        return jsonify({'message': 'Product not found in cart'}), 404

    db.session.delete(order)
    db.session.commit()

    return jsonify({'message': 'Removed from cart'}), 200

@app.route('/api/cart')
@token_required
def view_cart(current_user):
    orders = Order.query.filter_by(user_id=current_user.id, status='pending').all()
    product_ids = [o.product_id for o in orders]
    if not product_ids:
        return jsonify([])  # Empty cart

    products = Product.query.filter(Product.id.in_(product_ids)).all()
    return jsonify([p.to_dict() for p in products])
@app.route('/api/products/<int:product_id>', methods=['DELETE'])
@token_required
def delete_product(current_user, product_id):
    product = Product.query.get_or_404(product_id)

    # Authorization check
    if not (product.user_id == current_user.id or current_user.is_admin):
        return jsonify({'message': 'Unauthorized: You can only delete your own products'}), 403

    try:
        # Get all images to delete
        all_images = [product.image_path]
        if product.extra_images:
            all_images.extend(product.extra_images.split(','))
        
        # Delete files from filesystem
        for image in all_images:
            if image:  # Skip empty strings
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], image)
                if os.path.exists(file_path):
                    os.remove(file_path)
        
        # Delete from database
        db.session.delete(product)
        db.session.commit()
        
        return jsonify({'message': 'Product and associated images deleted successfully'}), 200

    except Exception as e:
        db.session.rollback()
        app.logger.error(f'Error deleting product {product_id}: {str(e)}')
        return jsonify({
            'message': 'Failed to delete product',
            'error': str(e)
        }), 500
        
@app.route('/api/users/me')
@token_required
def get_current_user(current_user):
    return jsonify({
        'id': current_user.id,
        'username': current_user.username,
        'is_admin': current_user.is_admin
    })
@app.route('/api/products/<int:product_id>', methods=['PUT'])
@token_required
@admin_required
def approve_product(current_user, product_id):
    product = Product.query.get_or_404(product_id)
    product.is_approved = True
    db.session.commit()
    print(f"Product approved: {product.to_dict()}")  # Debugging statement
    return jsonify(product.to_dict())

@app.route('/api/my-products')
@token_required
def my_products(current_user):
    # Option 1: Show all products the user has bought
    orders = Order.query.filter_by(user_id=current_user.id, status='completed').all()
    bought_product_ids = [o.product_id for o in orders if o.product_id]

    # Option 2: Show all products the user has uploaded (approved or not)
    sold_products = Product.query.filter_by(user_id=current_user.id).all()

    # Combine both lists
    bought_products = Product.query.filter(
        Product.id.in_(bought_product_ids)
    ).all()

    # Return both sets as separate sections if needed
    return jsonify({
        'purchased': [p.to_dict() for p in bought_products],
        'uploaded': [p.to_dict() for p in sold_products]
    }), 200
@app.route('/api/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
@app.route('/api/users/grant-upload/<int:user_id>', methods=['PUT'])
@token_required
@admin_required
def grant_upload_permission(current_user, user_id):
    user = User.query.get_or_404(user_id)
    user.can_upload = not user.can_upload  # Toggle permission
    db.session.commit()
    return jsonify({
        'message': 'Upload permission updated',
        'can_upload': user.can_upload,
        'username': user.username
    }), 200
@app.route('/api/users', methods=['GET', 'OPTIONS'])
@cross_origin()
@token_required
@admin_required
def get_users(current_user):
    print(request.headers)  # Debugging statement
    if request.method == 'OPTIONS':
        response = jsonify({})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,OPTIONS')
        return response, 200

    users = User.query.all()
    return jsonify([user.to_dict() for user in users]), 200


@app.route('/api/contact-us', methods=['POST'])
def contact_us():
    data = request.get_json()

    # Extract necessary information from the request
    product_info = data.get('product_info', {})
    user_phone_number = data.get('phone_number')
    user_email = data.get('email')
    user_message = data.get('message')
    supplier_info = data.get('supplier_info', {})

    # Validate the data
    if not user_phone_number or not user_email or not user_message:
        return jsonify({'message': 'Missing required fields'}), 400

    # Create an email message
    subject = "New Contact Us Submission"
    body = f"""
    You have received a new contact form submission:

    User Phone Number: {user_phone_number}
    User Email: {user_email}
    User Message: {user_message}

    Product Info:
    {product_info}

    Supplier Info:
    {supplier_info}
    """

    # Get all admin emails
    admins = User.query.filter_by(is_admin=True).all()
    admin_emails = [admin.email for admin in admins]

    try:
        # Send the email to all admins
        msg = Message(subject, recipients=admin_emails)
        msg.body = body
        msg.sender = app.config['MAIL_DEFAULT_SENDER']
        mail.send(msg)

        return jsonify({'message': 'Contact form submitted successfully'}), 200
    except Exception as e:
        return jsonify({'message': f'Failed to send contact form: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
